return {
	require("default.resprays"),
	require("default.laps"),
	require("default.block_popups"),
	-- require("hello.hello"),
	-- require("foo.foo"),
	require("solo.solo"),
	require("fps.fps"),
	require("revs.revs"),
}
