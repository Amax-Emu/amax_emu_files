-- This M thing represents the Lua module:
--  Everything in there will be passed to the plugin loader.
local M = {
	HOOKS = {
		ORG_net_StartServiceConnection = nil,
	},
}


M.CONFIG = {
	debugs = true,
}


-- Every plugin should have an info table.
M.info = {
	name = "Porygon",
	description = "AMAX Porygon. You need this to login to AMAX.",
	version = 0.1
}


function M.porygon(username)
	--print_api("Hello from amax/plugins/porygon/porygon.lua::M.hook_porygon("..username..")")

	-- porygon.dll Can subscribe to this event and run their spooky rust code from there.
	notify(1) -- Notify event :>
end




function M.GoScreen(screen, opts)
	if screen == "Account\\NetLogin.lua" then
		if net_StartServiceConnection then
			if not M.HOOKS.ORG_net_StartServiceConnection then
				if M.CONFIG.debugs then
					print_api("HOOKING: net_StartServiceConnection()")
				end
				M.HOOKS.ORG_net_StartServiceConnection = net_StartServiceConnection
			end
			M.HOOKS.HOOK_net_StartServiceConnection = function(online_mode, callback, active)
				if M.CONFIG.debugs then
					print_api("HOOK_net_StartServiceConnection("
					.."online_mode = "..tostring(online_mode)..", "
					.."callback = "..tostring(callback)..", "
					.."active = "..tostring(active)
					..")")
				end
				if (online_mode) and (active == nil) then
					-- print_api(GUI.username_id)
					M.porygon("I_DONT_HAVE_A_USERNAME_YET")
				end
				M.HOOKS.ORG_net_StartServiceConnection(online_mode, callback, active)
			end
			net_StartServiceConnection = M.HOOKS.HOOK_net_StartServiceConnection
		end
	end
end


-- This will be called when the plugin loads
function M.init()
	print_api("Initializing Porygon") -- Do the thing :D

	-- FIXME: Ship with lua51.dll so we can all Rust from here, directly.
	-- Ideal way would be to do all this from Rust, with a lib-porygon.dll:
	-- local lib_porygon = require("porygon.lib-porygon")
	--   The problem we face is that right now, that lib-porygon.dll would have to use a lua51.dll as a runtime.
	--   The game uses it's own runtime, and on hooking lua_loadbuffer(), we use a vendored runtime (mlua --features "vendored").
	-- If I figure out a way for lua_hooks.dll & any plugin DLLs to agree to use lua51.dll, I'll update this.

	return true -- true means we loaded correctly
end

return M -- Return this plugin




-- TOOD: Better login hooks:
		--[[
		if screen == "multiplayer\\mpmain.lua" then
			print_api("i do the thing blyat: MpMain_EnterOnline")
			if not BlurAPI.ORG_MpMain_EnterOnline then
				print_api("HOOKING: MpMain_EnterOnline()")
				BlurAPI.ORG_MpMain_EnterOnline = MpMain_EnterOnline
			end
			BlurAPI.HOOK_MpMain_EnterOnline = function()
				print_api("HOOK_MpMain_EnterOnline()")
				BlurAPI.ORG_MpMain_EnterOnline()
			end
			MpMain_EnterOnline = BlurAPI.HOOK_MpMain_EnterOnline
		end

		if screen == "Account\\NetLogin.lua" then
			if net_MpEnter then
				print_api("i do the thing blyat: net_MpEnter")
				if not BlurAPI.ORG_net_MpEnter then
					print_api("HOOKING: net_MpEnter()")
					BlurAPI.ORG_net_MpEnter = net_MpEnter
				end
				BlurAPI.HOOK_net_MpEnter = function(mode)
					print_api("UW UWUWUWUWU   HOOK_net_MpEnter("
						.."mode = "..tostring(mode)
						..")")
					BlurAPI.ORG_net_MpEnter(mode)
				end
				net_MpEnter = BlurAPI.HOOK_net_MpEnter
			else
				print_api("No net_MpEnter??")
			end
		end
		]]--
