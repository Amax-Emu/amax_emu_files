return {
	require("resprays.resprays"),
	require("solo.solo"),
	require("revs.revs"),
	require("amax-auth.porygon"),
}
